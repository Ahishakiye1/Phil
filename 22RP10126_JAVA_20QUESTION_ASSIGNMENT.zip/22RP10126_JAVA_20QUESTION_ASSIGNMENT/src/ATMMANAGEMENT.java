import java.util.Scanner;
class atm
{
int account;
int amounttowithdraw;
int withrawallimit=1000;
int accountbal;
String location="KIBUYE BPOX12";

 atm(int acc,int amount)
 {
account=acc;
amounttowithdraw=amount;
 }
 
void accountdetails()
{
System.out.println("location is: " +location);

System.out.println("my account asset:" + account);

if(account>0 && amounttowithdraw<account )
{
System.out.println("You are allowed to withdraw cash out");
}
else
    {
System.out.println("You want to withdraw cash above current account");
}
}

void withdrawdetails()
{
System.out.println("my amount to withdraw is: "+amounttowithdraw);

if(amounttowithdraw<=withrawallimit && account>0 && account>=amounttowithdraw  )
{
     accountbal=account-amounttowithdraw;     
  System.out.println("amount withdrawn is: "+amounttowithdraw );  
        System.out.println("remaing account balance is: "+accountbal );
    

}
else{
  System.out.println("You are not allowed to withdraw cash out, your amount to withdraw is bellow minimum, please recharge and chech account current balance!! ");
}
}

}

public class ATMMANAGEMENTPROGRAM {

    public static void main(String[] args) {
     System.out.println("excutable program let's go get it!");
        System.out.println("====================================");
        
        int a,b;
                  
System.out.println("enter your account");
Scanner acc= new Scanner(System.in);
a=acc.nextInt();

System.out.println("Enter amount you want to withdraw");
Scanner withdraw= new Scanner(System.in);
b=withdraw.nextInt();

atm cash=new atm(a,b);

cash.accountdetails();
cash.withdrawdetails();
 
    }
}
