import java.util.Scanner;

public class SUMBTNNUMBERS {
    
    static int num1;
    static int num2;
    static int x;
    static int sum=0;
    
    static void givevalue(int n,int m)
    {
    num1=n;
    num2=m;
    }
    
static void sumbetweentwonumbers()
{
for(x=num1;x<=num2;x++)
{
sum+=x;
}
   System.out.println("sum between "+ num1+ " and " + num2+ " is :"+ sum);
}


    public static void main(String[] args) {
        System.out.println("excutable program let's go get it!");
        System.out.println("====================================");
        int a,b;
      
System.out.println("Enter first number");
Scanner num1= new Scanner(System.in);
a=num1.nextInt();

System.out.println("Enter second number");
Scanner num2= new Scanner(System.in);
b=num2.nextInt();

givevalue(a,b);
sumbetweentwonumbers();


        
        
    }
}
