import java.util.Scanner;
class rectangle
{
int length,width;

 void setval(int len,int wid)
 {
 width=wid;
 length=len;

 }
void calculatearea()
{
   int area=length*width;
System.out.println("area of rectangle = "+area);

}

void calculateperimeter()
{
   int perimeter=(length+width)*2;
System.out.println("area of rectangle = " + perimeter);

}

}

public class Question1 {

    public static void main(String[] args) {
        System.out.println("excutable function let's go get it!");
        
        int a,b;
        rectangle rect=new rectangle();      
        
     
System.out.println("Enter length of rectangle");
Scanner len= new Scanner(System.in);
a=len.nextInt();

System.out.println("Enter width of rectangle");
Scanner wid= new Scanner(System.in);
b=wid.nextInt();

rect.setval(a, b);
rect.calculatearea();
rect.calculateperimeter();
        
        
    }
}
